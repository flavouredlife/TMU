#### High level business workflow

UI / UX links

BDM

https://xd.adobe.com/view/96f47e72-472a-4868-9711-516ccadf0a43-c3a7/

CRM

https://xd.adobe.com/view/dcc798f4-0d79-46da-8b88-6e6a9acd05d4-8994/

SRM

https://xd.adobe.com/view/b28e1009-16fe-45be-8c9b-bb82ffbcaa94-e7dd/

Admin

https://xd.adobe.com/view/b83072a3-c93a-4fb8-97ef-f82c563b51a8-ed63/

Candidate

https://xd.adobe.com/view/1bbb4d3e-ee68-46a5-a3aa-6cc49fdd4959-4ee8/

Reference

https://xd.adobe.com/view/de7e81fc-6149-44a4-bacd-08dffcf8bbb4-8b2d/

Applicant

https://xd.adobe.com/view/b37e146e-bd7b-4278-b4b7-8d168bf1c2ee-e62d/

CaseManager 

https://xd.adobe.com/view/92fbe0d0-45e9-4a2b-ba26-59460b04ec06-c7a8/
