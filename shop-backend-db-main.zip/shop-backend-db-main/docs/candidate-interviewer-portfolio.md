# Resume Database
We will add resumes to resume portal

Each SRM will add resumes to create a portofolio.

lock resumes or open resumes.

Sharing resumes with other srms and at a % this will be shown when the other srm asks for sharing.

Resumes can be in chain or not in chain


SRM Portfolios Chalapathi

SRM will have chains and not chains resume

company

services

products

bench profiles

email and phone number is sufficient

SRM Send email notifications to company with what services they are providing

SRM gets recommended candidates based on job filters

Candidate can apply directly as well and srms will be notified 

Rate negotiation screen is not there

CRM works with Company and SRM is working Candidate to improve the score. Pre Screening attributes

Applicant profile gets created when he applies for a job

zetty resume builders / job description templates / resume templates
