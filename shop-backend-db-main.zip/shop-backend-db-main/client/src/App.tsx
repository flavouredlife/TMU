import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import './App.css'

const App = () => <h1>hello world</h1>

export default App;
