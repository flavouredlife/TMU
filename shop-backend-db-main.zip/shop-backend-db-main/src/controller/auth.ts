import * as UserService from "../db/services/user"
import {UserOutput, UserInput} from "../db/models/User"


interface LoginResponse {
    access_token: string

}


export const signup = async(userData:any): Promise<UserInput> => {
    let userExists =  await UserService.checkUserExist(userData.email, userData.phone_no)
    if (userExists) {
        throw new Error("User already exists")
        
    }
    else{
        const user = await UserService.create(userData)
        return user
    }

}

export const login = async(userData:any): Promise<LoginResponse> => {
    const user : any= await UserService.findByEmail(userData.email)
    if (user.length == 0) {
        throw new Error("User not found")
    }else{
      return  Promise.resolve({access_token:"sample"})
    
    }
}