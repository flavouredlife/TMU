interface ListFilters {
	isDeleted?: boolean;
	includeDeleted?: boolean;
}

export interface GetAllUserFilters extends ListFilters {}
export interface GetAllJobPostFilters extends ListFilters {}