import { DataTypes, Model, Optional } from "sequelize";
import sequelizeConnection from "../config";

interface UserAttributes {
    id:number;
    firstName:string;
    lastName:string;
    userName:string;
    password:string;
    email:string;
    phone:string;

    createdAt?:Date;
    updatedAt?:Date;
    deleteAt?:Date;
}

export interface UserInput extends Optional<UserAttributes, "id"> {}

export interface UserOutput extends Required<UserAttributes>{} 

class User
	extends Model<UserAttributes, UserInput>
	implements UserAttributes
{
	public id!: number;
    public firstName!:string;
    public lastName!:string;
    public userName!:string;
    public password!:string;
    public email!:string;
    public phone!:string;

    public readonly createdAt!:Date;
    public readonly updatedAt!:Date;
    public readonly deleteAt!:Date;
}

User.init(
		{
			id:{
				type:DataTypes.INTEGER.UNSIGNED,
				autoIncrement:true,
				primaryKey:true,
			},
			firstName:{
				type:DataTypes.STRING,
				allowNull:false,
			},
			lastName:{
				type:DataTypes.STRING,
				allowNull:false,
			},
			userName:{
				type:DataTypes.STRING,
				allowNull:false,
			},
			password:{
				type:DataTypes.STRING,
				allowNull:false,
			},
			email:{
				type:DataTypes.STRING,
				allowNull:false,
			},
			phone:{
				type:DataTypes.STRING,
				allowNull:false,
			}
		
		
		},{
			timestamps: true,
		  sequelize: sequelizeConnection,
		  paranoid: true
		}
);

export default User;


export const toUser = (user: UserOutput) => {
    return {
        
		id:user.id,
		firstName:user.firstName,
		lastName:user.lastName,
		userName:user.userName,
		password:user.password,
		email:user.email,
		phone:user.phone,

        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
        deletedAt: user.deleteAt,
    }
}


export type CreateUserDTO = {
    id: number;
	firstName: string;
	lastName: string;
	userName: string;
    password: string;
    email: string;
	phone: string;
}

export type UpdateUserDTO = Optional<CreateUserDTO,"id" >

export type FilterUserDTO = {
    isDeleted?: boolean
    includeDeleted?: boolean
}