import request from "supertest";
const API_DOMAIN_URL = "http://localhost:3000/api/v1";


//getting the all user
test("Test all User", async () => {
	const response = await request(API_DOMAIN_URL)
		.get("/users")
		.send();

	expect(response.statusCode).toBe(200);
});

// adding user 
test("Test signup and resignup for user", async () => {
	const content:any ={
		username: "smith",
		first_name: "willow ",
		last_name: "smith",
		email: "smith@gmail.com",
		password: "password",
		confirm_password: "password",
		phone_no: "114452226789"
	}
	let response = await request(API_DOMAIN_URL)
		.post("/auth/signup")
		.send(content)
	expect(response.statusCode).toBe(201);
	

})


